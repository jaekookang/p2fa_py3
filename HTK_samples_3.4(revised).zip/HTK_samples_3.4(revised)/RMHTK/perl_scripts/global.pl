##
## global.pl: Global variables for RM DEMO
## Need to set enviroment variable RMSCRIPTS (path name for RM scripts)
##      for the whole scripts to work.
##
##      TL 7/1998
##

$RMWORK      = "c\:\\dp\\rmdemo\\work";
$RMLIB       = "c\:\\dp\\rmdemo\\lib";
$RMDATA      = "c\:\\dp\\rmdemo\\data";
$RMCD1       = "d\:\\";
$RMCD2       = "d\:\\";
$RMCD3       = "d\:\\";

1;
